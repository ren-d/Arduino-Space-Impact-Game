#ifndef MATH_H
#define MATH_H
#include "Math.h"
class Math
{
public:
    
    int Clamp(int value, int min, int max);
    float SQRT(int value);
};
#endif