#include "Vector2.h"

//uses constructors
Vector2::Vector2()
{
		x = 0;
		y = 0;
}

//can define a vector 2 data type like so
Vector2::Vector2(int x, int y)
{
		this->x = x;
		this->y = y;
}
